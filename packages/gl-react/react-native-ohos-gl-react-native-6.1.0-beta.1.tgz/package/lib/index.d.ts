import "webgltexture-loader-expo";
export declare const Surface: any;
//# sourceMappingURL=index.d.ts.map